/*
 * servo.h
 *
 * Created: 21/04/26
 * Author: Jose M�ndez
 * Description: Archivo para configurar el servo en tipo H.
 */
#ifndef SERVO_H_
#define SERVO_H_

#include <stdint.h>

void Servo_init(void); //Funci�n de configuraci�n de timers y pines
void Servo_angle(uint8_t servo, uint8_t angle); //Funci�n para mover el servo
uint8_t Servo_save(uint8_t servo); //Funci�n para guardar el angulo en la EEPROM

#endif